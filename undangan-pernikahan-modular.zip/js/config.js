export const weddingConfig = {
  groomName: "Chaska Vebriansyah",
  brideName: "Feristha Mathasia",
  weddingDate: "2027-01-27",
  // If exact event time is unknown, countdown uses midnight Jakarta time.
  eventTime: "00:00",
  timezone: "Asia/Jakarta",
  address: "Mulyorejo 2, Kecamatan Bunga Mayang, Kabupaten Lampung Utara, Lampung, Indonesia",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Mulyorejo%202%2C%20Kecamatan%20Bunga%20Mayang%2C%20Kabupaten%20Lampung%20Utara%2C%20Lampung",
  whatsappNumber: "6285773334303",
  bankName: "BRI",
  accountNumber: "731301005654507",
  accountHolder: "CHASKA VEBRIANSYAH",
  musicPath: "music/wedding.mp3",
  groomPhoto: "images/chaska.jpeg",
  bridePhoto: "images/feristha.jpeg",
  akadTime: "Waktu akan diinformasikan",
  receptionTime: "Waktu akan diinformasikan",
  parentsGroom: "Nama orang tua belum dilengkapi",
  parentsBride: "Nama orang tua belum dilengkapi"
};
