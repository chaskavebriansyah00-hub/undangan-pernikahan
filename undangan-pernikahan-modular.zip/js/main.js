import { weddingConfig as config } from "./config.js";

const sectionFiles = [
  ["intro", "sections/intro.html"],
  ["couple", "sections/couple.html"],
  ["events", "sections/events.html"],
  ["location", "sections/location.html"],
  ["gallery", "sections/gallery.html"],
  ["story", "sections/story.html"],
  ["prayer", "sections/prayer.html"],
  ["gift", "sections/gift.html"],
  ["contact", "sections/contact.html"],
  ["footer", "sections/footer.html"]
];

async function loadSections() {
  for (const [id, path] of sectionFiles) {
    const response = await fetch(path);
    if (!response.ok) throw new Error(`Tidak dapat memuat ${path}`);
    document.getElementById(`section-${id}`).innerHTML = await response.text();
  }

  applyConfig();
  initializeInteractions();
}

function applyConfig() {
  const textMap = {
    groomName: config.groomName,
    brideName: config.brideName,
    bankName: config.bankName,
    accountNumber: config.accountNumber,
    accountHolder: config.accountHolder,
    weddingAddress: config.address,
    akadTime: config.akadTime,
    receptionTime: config.receptionTime,
    parentsGroom: config.parentsGroom,
    parentsBride: config.parentsBride
  };

  for (const [id, value] of Object.entries(textMap)) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  }

  document.querySelectorAll("[data-groom-photo]").forEach(img => {
    img.src = config.groomPhoto;
  });
  document.querySelectorAll("[data-bride-photo]").forEach(img => {
    img.src = config.bridePhoto;
  });

  document.querySelectorAll("[data-maps-link]").forEach(link => {
    link.href = config.mapsUrl;
  });

  document.querySelectorAll("[data-whatsapp-link]").forEach(link => {
    const message = "Assalamu'alaikum, saya ingin mengirimkan ucapan pernikahan untuk " +
      config.groomName + " dan " + config.brideName + ".";
    link.href = `https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`;
  });

  const date = new Date(`${config.weddingDate}T${config.eventTime}:00+07:00`);
  const dateText = new Intl.DateTimeFormat("id-ID", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
    timeZone: "Asia/Jakarta"
  }).format(date);

  const coverDate = document.getElementById("coverDate");
  if (coverDate) coverDate.textContent = dateText;

  document.querySelectorAll("[data-wedding-date]").forEach(el => {
    el.textContent = dateText;
  });

  document.querySelectorAll("[data-couple-names]").forEach(el => {
    el.textContent = `${config.groomName} & ${config.brideName}`;
  });

  startCountdown(date.getTime());
}

function startCountdown(target) {
  let timer;
  const update = () => {
    const remaining = target - Date.now();
    const ids = ["days", "hours", "minutes", "seconds"];

    if (remaining <= 0) {
      ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = "0";
      });
      const message = document.getElementById("countdownMessage");
      if (message) message.textContent = "Hari bahagia telah tiba. Semoga penuh berkah!";
      clearInterval(timer);
      return;
    }

    const values = [
      Math.floor(remaining / 86400000),
      Math.floor((remaining % 86400000) / 3600000),
      Math.floor((remaining % 3600000) / 60000),
      Math.floor((remaining % 60000) / 1000)
    ];

    ids.forEach((id, i) => {
      const el = document.getElementById(id);
      if (el) el.textContent = i === 0 ? values[i] : String(values[i]).padStart(2, "0");
    });

    const message = document.getElementById("countdownMessage");
    if (message) message.textContent = "Menghitung waktu menuju hari pernikahan.";
  };

  update();
  timer = setInterval(update, 1000);
}

function initializeInteractions() {
  const params = new URLSearchParams(window.location.search);
  const guest = params.get("to");
  if (guest) document.getElementById("guestName").textContent = guest.slice(0, 100);

  const cover = document.getElementById("cover");
  const invitation = document.getElementById("invitation");
  const music = document.getElementById("weddingMusic");
  const musicButton = document.getElementById("musicButton");

  document.getElementById("openInvitation").addEventListener("click", async () => {
    invitation.classList.remove("hidden");
    invitation.classList.add("fade-in");
    musicButton.classList.remove("hidden");
    cover.style.display = "none";
    window.scrollTo({ top: 0, behavior: "smooth" });

    try {
      await music.play();
      musicButton.textContent = "♫";
      musicButton.classList.add("playing");
    } catch {
      musicButton.textContent = "♪";
    }
  });

  musicButton.addEventListener("click", async () => {
    if (music.paused) {
      try {
        await music.play();
        musicButton.textContent = "♫";
        musicButton.classList.add("playing");
      } catch {
        alert("Musik belum tersedia. Unggah file berlisensi wedding.mp3 ke folder music/.");
      }
    } else {
      music.pause();
      musicButton.textContent = "♪";
      musicButton.classList.remove("playing");
    }
  });

  document.getElementById("copyAccount").addEventListener("click", async () => {
    const message = document.getElementById("copyMessage");
    try {
      await navigator.clipboard.writeText(config.accountNumber);
      message.textContent = "Nomor rekening berhasil disalin.";
    } catch {
      message.textContent = `Nomor rekening: ${config.accountNumber} (silakan salin manual).`;
    }
  });

  document.querySelectorAll(".gallery img").forEach(img => {
    img.addEventListener("click", () => {
      document.getElementById("lightboxImage").src = img.src;
      document.getElementById("lightboxImage").alt = img.alt;
      document.getElementById("lightbox").classList.remove("hidden");
    });
  });

  const closeLightbox = () => {
    document.getElementById("lightbox").classList.add("hidden");
    document.getElementById("lightboxImage").src = "";
  };

  document.getElementById("closeLightbox").addEventListener("click", closeLightbox);
  document.getElementById("lightbox").addEventListener("click", event => {
    if (event.target.id === "lightbox") closeLightbox();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeLightbox();
  });
}

loadSections().catch(error => {
  console.error(error);
  document.getElementById("invitation").classList.remove("hidden");
  document.getElementById("invitation").innerHTML =
    '<section><h2>Undangan sedang diperbarui</h2><p>Muat ulang halaman beberapa saat lagi.</p></section>';
});
