WEBSITE UNDANGAN PERNIKAHAN MODULAR

Folder:
- index.html: halaman utama dan wadah bagian-bagian.
- sections/: bagian undangan terpisah.
- css/style.css: desain.
- js/config.js: data pasangan, tanggal, rekening, WhatsApp, lokasi, foto.
- js/main.js: memuat bagian dan menjalankan fitur.
- images/: foto pasangan.
- music/wedding.mp3: file musik yang perlu Anda tambahkan sendiri.

PENTING:
1. Pertahankan nama foto images/chaska.jpeg dan images/feristha.jpeg atau ubah path pada js/config.js.
2. Untuk musik, tambahkan file instrumental yang legal digunakan dengan nama music/wedding.mp3.
3. Buka undangan lewat deployment Vercel, bukan dengan membuka index.html langsung dari file lokal, karena bagian HTML dimuat menggunakan fetch().
4. Untuk mengubah nomor WhatsApp, edit whatsappNumber di js/config.js. Gunakan format internasional tanpa tanda + dan tanpa angka 0 di awal: 6285773334303.
5. Waktu akad dan resepsi belum diberikan, jadi konfigurasi masih menampilkan "Waktu akan diinformasikan".
6. Jika ingin mengubah galeri, edit sections/gallery.html.
